package com.example.appregistrogastos;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Adaptador para el RecyclerView que muestra la lista de categorías creadas por el usuario.
 * Permite visualizar cada categoría y eliminarla mediante un botón dedicado.
 * Este adaptador trabaja con una lista de Strings (los nombres de categoría).
 */
public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder> {

    // Lista de nombres de categorías que se mostrarán en pantalla
    private List<String> categories;

    // Listener que permite notificar al fragmento cuando se solicita eliminar una categoría
    private OnCategoryDeleteListener deleteListener;

    /**
     * Interfaz de callback que envía la posición del elemento que se desea eliminar.
     */
    public interface OnCategoryDeleteListener {
        void onDelete(int position);
    }

    /**
     * Constructor del adaptador.
     * @param categories lista de categorías a mostrar
     * @param deleteListener referencia al método que gestionará la eliminación
     */
    public CategoryAdapter(List<String> categories, OnCategoryDeleteListener deleteListener) {
        this.categories = categories;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Infla el layout XML que representa un item de categoría en el RecyclerView
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_category, parent, false);
        return new CategoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder holder, int position) {
        // Vincula el nombre y el botón de eliminar con su comportamiento correspondiente
        holder.bind(categories.get(position), deleteListener, position);
    }

    @Override
    public int getItemCount() {
        // Devuelve la cantidad de categorías a mostrar
        return categories != null ? categories.size() : 0;
    }

    /**
     * Clase interna que representa cada vista (fila) dentro del RecyclerView.
     * Maneja los elementos gráficos y las acciones del usuario.
     */
    static class CategoryViewHolder extends RecyclerView.ViewHolder {

        // Elemento que muestra el nombre de la categoría
        private TextView tvCategoryName;

        // Botón de eliminar la categoría
        private ImageButton btnDelete;

        public CategoryViewHolder(@NonNull View itemView) {
            super(itemView);

            // Relaciona los elementos visuales con sus IDs en el layout XML
            tvCategoryName = itemView.findViewById(R.id.tv_category_name);
            btnDelete = itemView.findViewById(R.id.btn_delete);
        }

        /**
         * Asigna valores y comportamiento a cada item.
         * @param category nombre de la categoría
         * @param listener callback para eliminar categoría
         * @param position posición actual del item en la lista
         */
        public void bind(String category, OnCategoryDeleteListener listener, int position) {

            // Muestra el nombre de la categoría
            tvCategoryName.setText(category);

            // Acción del botón eliminar: notifica al fragmento cuál categoría se debe eliminar
            btnDelete.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onDelete(position);
                }
            });
        }
    }
}
