package com.example.appregistrogastos;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Adaptador para mostrar el resumen de gastos por categoría.
 * Este adaptador recibe una lista de categorías con su monto total
 * y calcula el porcentaje correspondiente respecto al total de gastos.
 */
public class CategorySummaryAdapter extends RecyclerView.Adapter<CategorySummaryAdapter.CategoryViewHolder> {

    // Lista de objetos CategorySummary que contienen nombre y monto por categoría
    private List<CategorySummary> categories;

    // Total de gastos, usado para calcular el porcentaje correspondiente
    private double totalExpenses;

    // Constructor del adaptador que recibe la lista de categorías y el total de gastos
    public CategorySummaryAdapter(List<CategorySummary> categories, double totalExpenses) {
        this.categories = categories;
        this.totalExpenses = totalExpenses;
    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Infla el layout del item visual que representará cada categoría en el RecyclerView
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_category_summary, parent, false);
        return new CategoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder holder, int position) {
        // Obtiene la categoría correspondiente a la posición actual
        CategorySummary category = categories.get(position);

        // Llama al método bind() para asignar la información en la vista
        holder.bind(category, totalExpenses);
    }

    @Override
    public int getItemCount() {
        // Devuelve la cantidad de elementos a mostrar en el RecyclerView
        return categories != null ? categories.size() : 0;
    }

    /**
     * ViewHolder que representa el diseño de cada item en el RecyclerView.
     * Contiene referencias a los elementos visuales del layout.
     */
    static class CategoryViewHolder extends RecyclerView.ViewHolder {

        // Elementos que muestran el nombre de la categoría, monto, porcentaje y barra de progreso
        private TextView tvCategoryName;
        private TextView tvCategoryAmount;
        private TextView tvCategoryPercentage;
        private ProgressBar progressBar;

        public CategoryViewHolder(@NonNull View itemView) {
            super(itemView);

            // Se enlazan los elementos del layout con sus IDs
            tvCategoryName = itemView.findViewById(R.id.tv_category_name);
            tvCategoryAmount = itemView.findViewById(R.id.tv_category_amount);
            tvCategoryPercentage = itemView.findViewById(R.id.tv_category_percentage);
            progressBar = itemView.findViewById(R.id.progress_bar);
        }

        /**
         * Método encargado de asignar los valores visuales a cada item.
         * Calcula el porcentaje según el total de gastos e inicializa la barra.
         */
        public void bind(CategorySummary category, double totalExpenses) {

            // Mostrar nombre de la categoría
            tvCategoryName.setText(category.getCategoryName());

            // Mostrar el monto total gastado en la categoría con formato
            tvCategoryAmount.setText("S/ " + String.format("%.2f", category.getAmount()));

            // Cálculo del porcentaje (si totalExpenses es 0, se evita dividir)
            int percentage = totalExpenses > 0 ? (int) ((category.getAmount() / totalExpenses) * 100) : 0;

            // Mostrar porcentaje como texto
            tvCategoryPercentage.setText(percentage + "%");

            // Actualizar barra de progreso visual con el porcentaje
            progressBar.setProgress(percentage);
        }
    }
}
